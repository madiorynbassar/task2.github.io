<?php 
//Подключение
$db = new PDO('mysql:host=localhost;dbname=users','root','');

?>